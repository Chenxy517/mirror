/* This code is part of the GenSync project developed at Boston University. Please see the README for use and references. */

/*
 * File:   CommDummy.cpp
 * Author: Eliezer Pearl
 * 
 * Created on May 24, 2018, 10:13 AM
 */

#include <GenSync/Communicants/CommDummy.h>

CommDummy::CommDummy(queue<char> *intermediate) {
    this->intermediate = intermediate;
}

CommDummy::~CommDummy() = default;

// No action needed to listen to the intermediate.
void CommDummy::commListen() {
}

// No action needed to connect to the intermediate.
void CommDummy::commConnect() {
}

// No action needed to close connection with intermediate.
void CommDummy::commClose() {
}

void CommDummy::commSend(const char* toSend, size_t numBytes) {
    // If numBytes is zero, then toSend's length must be calculated.
    const int calcLen = 0;
    const size_t bytes = numBytes == calcLen ? strlen(toSend) : numBytes;
    for (int i = 0; i < numBytes; i++)
        intermediate->emplace(toSend[i]);

    // Update transmitted-bytes-counter.
    addXmitBytes(bytes);
}

string CommDummy::commRecv(unsigned long numBytes) {
    // Create a stringstream to store the first numBytes characters.
    stringstream recv;

    // Get the first numBytes characters.
    for (int i = 0; i < numBytes; i++) {
        recv << intermediate->front();
        intermediate->pop();
    }

    // Update received-bytes-counter.
    addRecvBytes(numBytes);
    return recv.str();
}
