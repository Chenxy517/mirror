## <CPISync/Syncs/>
* For most use cases, the user will only have to interact with the GenSync object and all other sync methods will have their functions called only from GenSync, but it may be useful in some cases to manually call SyncMethod methods

* **GenSync.h**
    * TODO: FILL THIS SECTION
